# Define constant
Pi = 3.14159
# Get radius from user
radius = float(input("Enter radius of the circle: "))
# Calculate area
area = Pi * radius ** 2
# Display result
print("Area of the circle is:", area)
