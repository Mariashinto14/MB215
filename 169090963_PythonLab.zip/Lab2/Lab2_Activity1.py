#ask for user's name
name = input("What is your name? ")
#ask for user's age
age = (input("How old are you? "))
#display greeting message
print("Hello",name,"you are",age,"years old.")
#calculate birth year
current_year = 2026 
birth_year = current_year - int(age)
#display birth year
print("You were born in the year",birth_year)
