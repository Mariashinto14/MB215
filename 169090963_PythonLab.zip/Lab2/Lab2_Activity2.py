# ask for rectangle length
length = float(input("Enter the rectangle length: "))
# ask for rectangle width
width = float(input("Enter the rectangle width: "))
# calculate area
area = length * width
# display area
print("The area of the rectangle is:", area)
