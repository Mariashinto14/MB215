#ask the user for string 1
string1 = input("Enter your first name and last name: ")
#ask the user for string 2
string2 = input("Enter your gender: ")
#ask the user for string 3
string3 = input("Enter your age: ")
#display the concatenated result
print("The user's name is " + string1 + " The user is a "+ string2 +" and is " + string3 + " years old.")

